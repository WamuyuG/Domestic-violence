# DMS
Disaster Management System 

### Landing Page 
----------
<p align="center">
  <img src="project previews/1.png" width="auto" height="auto"/>
</p>

### Login & Signup Page 
----------
<p align="center">
  <img src="project previews/2.png" width="auto" height="auto"/>
</p>

### Home Page 
----------
<p align="center">
  <img src="project previews/3.png" width="auto" height="auto"/>
</p>

### Incident Report Center Page

----------
<p align="center">
  <img src="project previews/4.png" width="auto" height="auto"/>
</p>

### Contact Us Page
----------
<p align="center">
  <img src="project previews/5.png" width="auto" height="auto"/>
</p>

### Admin Login Page
----------
<p align="center">
  <img src="project previews/6.png" width="auto" height="auto"/>
</p>

### Admin Dashboard Preview 
----------
<p align="center">
  <img src="project previews/7.png" width="auto" height="auto"/>
</p>


